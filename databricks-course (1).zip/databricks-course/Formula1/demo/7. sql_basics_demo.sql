-- Databricks notebook source
SHOW DATABASES;

-- COMMAND ----------

SELECT current_database();

-- COMMAND ----------

USE f1_processed;

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

SELECT * FROM f1_processed.drivers LIMIT 10

-- COMMAND ----------

DESC f1_processed.drivers

-- COMMAND ----------

SELECT * FROM f1_processed.drivers WHERE nationality="British" and dob>='1990-01-01'

-- COMMAND ----------

SELECT name,dob AS date_of_birth
 FROM f1_processed.drivers 
 WHERE nationality="British" and dob>='1990-01-01'

-- COMMAND ----------

SELECT name,dob AS date_of_birth,nationality
 FROM f1_processed.drivers
 WHERE (nationality="British" and dob>='1990-01-01') OR nationality="Indian"
ORDER BY name ASC,dob DESC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### SQL functions

-- COMMAND ----------

SELECT *,CONCAT(driver_ref,'-',code) AS new_driver_ref
 FROM f1_processed.drivers;

-- COMMAND ----------

SELECT *,SPLIT(name,' ') [0] forename,SPLIT(name,' ')[1] surname
 FROM f1_processed.drivers;

-- COMMAND ----------

SELECT *,current_timestamp() as current_timestamp
 FROM f1_processed.drivers

-- COMMAND ----------

SELECT *,date_format(dob,'dd-MM-yyyy')
 FROM f1_processed.drivers;

-- COMMAND ----------

SELECT *,date_add(dob,1) AS dob_add
 FROM f1_processed.drivers;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Aggregate functions

-- COMMAND ----------

SELECT COUNT(*) FROM drivers;

-- COMMAND ----------

SELECT MAX(dob) FROM drivers;

-- COMMAND ----------

SELECT nationality, COUNT(nationality) AS NUM
 FROM drivers 
 GROUP BY nationality
 HAVING COUNT(*)>100
 ORDER BY NUM DESC;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Window Functions

-- COMMAND ----------

SELECT nationality,name,dob,RANK() OVER (PARTITION BY nationality ORDER BY dob DESC) AS rank
 FROM f1_processed.drivers
 ORDER BY nationality,rank


-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### JOINS

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_driver_standings_2018 
AS
SELECT race_year,driver_name,total_points,wins,rank
 FROM f1_presentation.driver_standings
 WHERE race_year=2018;

-- COMMAND ----------

SELECT * FROM v_driver_standings_2018;

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_driver_standings_2020
AS
SELECT race_year,driver_name,total_points,wins,rank
 FROM f1_presentation.driver_standings
 WHERE race_year=2020;

-- COMMAND ----------

SELECT * FROM v_driver_standings_2020;

-- COMMAND ----------

SELECT *
 FROM v_driver_standings_2018 as d_2018
 JOIN v_driver_standings_2020 as d_2020
  ON (d_2018.driver_name=d_2020.driver_name)

-- COMMAND ----------

SELECT *
 FROM v_driver_standings_2018 as d_2018
 LEFT JOIN v_driver_standings_2020 as d_2020
  ON (d_2018.driver_name=d_2020.driver_name)

-- COMMAND ----------

SELECT *
 FROM v_driver_standings_2018 as d_2018
 RIGHT JOIN v_driver_standings_2020 as d_2020
  ON (d_2018.driver_name=d_2020.driver_name)

-- COMMAND ----------

SELECT *
 FROM v_driver_standings_2018 as d_2018
 FULL JOIN v_driver_standings_2020 as d_2020
  ON (d_2018.driver_name=d_2020.driver_name)

-- COMMAND ----------

SELECT *
 FROM v_driver_standings_2018 as d_2018
 SEMI JOIN v_driver_standings_2020 as d_2020
  ON (d_2018.driver_name=d_2020.driver_name)

-- COMMAND ----------

SELECT *
 FROM v_driver_standings_2018 as d_2018
 ANTI JOIN v_driver_standings_2020 as d_2020
  ON (d_2018.driver_name=d_2020.driver_name)

-- COMMAND ----------

SELECT *
 FROM v_driver_standings_2018 as d_2018
 CROSS JOIN v_driver_standings_2020 as d_2020
  ON (d_2018.driver_name=d_2020.driver_name)

-- COMMAND ----------

