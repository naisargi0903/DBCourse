# Databricks notebook source
# MAGIC %md
# MAGIC ### Access dataframes using SQL
# MAGIC #### Objectives:
# MAGIC 1. Create temporary view on df
# MAGIC 2. Access the view from SQL
# MAGIC 3. Access the view from Python cell

# COMMAND ----------

# %sql
# SELECT * FROM global_temp.gv_race_resultss

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

race_results_df.createTempView("v_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM v_race_results WHERE race_year == 2020

# COMMAND ----------

race_results_2019_df=spark.sql("SELECT * FROM v_race_results WHERE race_year == 2020")

# COMMAND ----------

