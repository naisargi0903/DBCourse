-- Databricks notebook source
DROP DATABASE IF EXISTS f1_presentation CASCADE;

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_presentation LOCATION "abfss://presentation@formula1storageacc.dfs.core.windows.net/"

-- COMMAND ----------

DESC DATABASE f1_presentation;

-- COMMAND ----------

