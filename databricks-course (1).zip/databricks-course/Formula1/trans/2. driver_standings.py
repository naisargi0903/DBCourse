# Databricks notebook source
# MAGIC %md
# MAGIC ### Produce driver standings

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")
display(race_results_df)

# COMMAND ----------

from pyspark.sql.functions import sum, count, when, col
driver_standings_df = race_results_df.groupBy("race_year", "driver_name","driver_nationality")\
    .agg(sum("points").alias("total_points"), count("race_year").alias("number_of_races"),count(when(col("position") == 1, True)).alias("wins"))

# COMMAND ----------

display(driver_standings_df.filter("race_year==2019"))

# COMMAND ----------

from pyspark.sql.functions import rank,desc
from pyspark.sql.window import Window

# COMMAND ----------

driver_standings_spec=Window.partitionBy("race_year").orderBy(desc("total_points"), desc("wins"))

driver_ranked_df=driver_standings_df.withColumn("rank",rank().over(driver_standings_spec))

# COMMAND ----------

display(driver_ranked_df.filter(col("race_year")==2020))

# COMMAND ----------

driver_ranked_df.write.mode("overwrite").format("parquet").saveAsTable("f1_presentation.driver_standings")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *FROM f1_presentation.driver_standings  

# COMMAND ----------

