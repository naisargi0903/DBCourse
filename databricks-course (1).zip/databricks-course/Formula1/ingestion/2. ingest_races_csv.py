# Databricks notebook source
# MAGIC %md
# MAGIC ### Ingest races.csv

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-21")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

races_df=spark.read.csv(f"{raw_folder_path}/{v_file_date}/races.csv")

# COMMAND ----------

# display(races_df)

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,DateType

# COMMAND ----------

races_schema=StructType(fields=[StructField("raceId",IntegerType(),False),
                               StructField("year",IntegerType(),True),
                               StructField("round",IntegerType(),True),
                               StructField("circuitId",IntegerType(),True),
                               StructField("name",StringType(),True),
                               StructField("date",DateType(),True),
                               StructField("time",StringType(),True),
                               StructField("url",StringType(),True)
                               ])

# COMMAND ----------

races_df=spark.read.option("header",True).schema(races_schema).csv(f"{raw_folder_path}/{v_file_date}/races.csv")

# COMMAND ----------

display(races_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### _Step_ 2: Add ingestion_date and race_timestamp to the df

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,concat,lit,col,to_timestamp

# COMMAND ----------

races_df_with_timestamp=races_df.withColumn("ingestion_date",   current_timestamp())\
    .withColumn("race_timestamp", to_timestamp(concat(col("date"),lit(" "),col("time")),"yyyy-MM-dd HH:mm:ss"))
display(races_df_with_timestamp)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setp 3: Select the columns as required

# COMMAND ----------

races_select_df = races_df_with_timestamp.select(
    col("raceId").alias("race_id"),
    col("year").alias("race_year"),
    col("round"),
    col("circuitId").alias("circuit_id"),
    col("name"),
    col("ingestion_date"),
    col("race_timestamp")
).withColumn("file_date",lit(v_file_date))
 #marked new names,since autocompleter is not aware of new names yet,works fine
#instead of alias,can also use .WithColumnRenamed("old name","new name")

display(races_select_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 4: Write the output to processed container in parquet format

# COMMAND ----------

races_select_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.races")

# COMMAND ----------

# %fs
# ls "abfss://processed@formula1storageacc.dfs.core.windows.net/races"

# COMMAND ----------

# display(spark.read.parquet("abfss://processed@formula1storageacc.dfs.core.windows.net/races"))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.races

# COMMAND ----------

# MAGIC %md
# MAGIC ### Partition By

# COMMAND ----------

# races_select_df.write.mode('overwrite').partitionBy("race_year").parquet("abfss://processed@formula1storageacc.dfs.core.windows.net/races")

# COMMAND ----------

