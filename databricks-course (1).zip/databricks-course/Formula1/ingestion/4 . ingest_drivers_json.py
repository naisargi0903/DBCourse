# Databricks notebook source
# MAGIC %md
# MAGIC ### Step 1: Ingest drivers.json

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-21")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,DateType

# COMMAND ----------

name_schema=StructType(fields=[StructField("forename",StringType(),True),
                                 StructField("surname",StringType(),True)])

# COMMAND ----------

drivers_schema=StructType(fields=[StructField("driverId",IntegerType(),False),
                                 StructField("driverRef",StringType(),True),
                                 StructField("number",IntegerType(),True),
                                 StructField("code",StringType(),True),
                                 StructField("name",name_schema),
                                 StructField("dob",StringType(),True),
                                 StructField("nationality",StringType(),True),
                                 StructField("url",StringType(),True)])

# COMMAND ----------

drivers_df=spark.read.option("header",True).schema(drivers_schema).json(f"{raw_folder_path}/{v_file_date}/drivers.json")

# COMMAND ----------

display(drivers_df)

# COMMAND ----------

drivers_df.printSchema() #printSchema for already loaded df,inferSchema as a option while loading df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Select/drop/rename the columns as req

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,col,concat,lit
drivers_with_columns_df=drivers_df.withColumnRenamed('driverId','driver_id')\
                                  .withColumnRenamed('driverRef','driver_ref')\
                                  .withColumn('ingestion_date',current_timestamp())\
                                  .withColumn("name",concat(col('name.forename'),lit(' '),col('name.surname')))

# COMMAND ----------

display(drivers_with_columns_df)

# COMMAND ----------

drivers_final_df=drivers_with_columns_df.drop(col('url'))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3 : Write o/p to parquet file in datalake

# COMMAND ----------

drivers_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.drivers")

# COMMAND ----------

# %fs
# ls "abfss://processed@formula1storageacc.dfs.core.windows.net/drivers"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *FROM f1_processed.drivers