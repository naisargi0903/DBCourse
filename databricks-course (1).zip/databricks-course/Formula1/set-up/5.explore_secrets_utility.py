# Databricks notebook source
dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.list('f1-scope')

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.getBytes('f1-scope','formula1-acc-key')

# COMMAND ----------

dbutils.secrets.get('f1-scope','formula1-acc-key')

# COMMAND ----------

