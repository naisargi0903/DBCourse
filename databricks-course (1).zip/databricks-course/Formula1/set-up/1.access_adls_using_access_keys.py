# Databricks notebook source
# MAGIC %md
# MAGIC ### Access Azure Data Lake using access keys
# MAGIC 1. set spark config fs.azure.account.key
# MAGIC 2. List files from demo container
# MAGIC 3. Read data

# COMMAND ----------

formula1acckey=dbutils.secrets.get('f1-scope','formula1-acc-key')

# COMMAND ----------

dbutils.secrets.list('f1-scope')


# COMMAND ----------

spark.conf.set(
    "fs.azure.account.key.formula1storageacc.dfs.core.windows.net",
    "BYoIP1FwBJ7yE+caXO9r24XoGc6eP+deFsp5Qj/9MIRxJ2rCmv/ktjqzpCrOr94zxr2Rt4OCJIaR+ASt5wPA6g=="
    )

# COMMAND ----------

spark.conf.set(
    "fs.azure.account.key.formula1storageacc.dfs.core.windows.net",
    formula1acckey
    )

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1storageacc.dfs.core.windows.net"))

# COMMAND ----------

