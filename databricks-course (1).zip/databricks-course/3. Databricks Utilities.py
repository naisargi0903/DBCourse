# Databricks notebook source
# MAGIC %md
# MAGIC ### Databricks Utilities
# MAGIC - File system utilties
# MAGIC - Secrets utilities
# MAGIC - Widgets utilities
# MAGIC - Nb workflow utilities

# COMMAND ----------

# MAGIC %md
# MAGIC ###File System Utilities

# COMMAND ----------

# MAGIC %fs ls / 

# COMMAND ----------

dbutils.fs.ls('/')
#for programmatic tasks

# COMMAND ----------

display(dbutils.fs.ls('/'))

# COMMAND ----------

items=dbutils.fs.ls('dbfs:/databricks-datasets/')
print(items)

# COMMAND ----------

folder_count=len([item for item in items if item.name.endswith('/')])   
file_count=len([item for item in items if not item.name.endswith("/")]) 
print(f"Found {folder_count} folders and {file_count} files")

# COMMAND ----------

dbutils.help()

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.fs.help('cp')

# COMMAND ----------

