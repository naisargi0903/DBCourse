# Databricks notebook source
# MAGIC %md
# MAGIC # Intro to Databricks Notebooks
# MAGIC Hi,This notebook is for an introduction to databricks notebooks!
# MAGIC
# MAGIC ### Let's get started!!
# MAGIC

# COMMAND ----------

print("Hello")
print("World")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 'Hello from sql!'