# Databricks notebook source
env = 'dev'

# COMMAND ----------

import os
import platform
def print_env_info():
    #Print python version
    print(f"Python version:{platform.python_version()}")
    #Print databricks runtime version
    # Get Databricks runtime version from Spark configuration
    runtime_version = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion")
    print(f"Databricks runtime version: {runtime_version}")
print_env_info()
 