# Databricks notebook source
# MAGIC %md
# MAGIC ### Mount Azure Data Lake using Service Principal
# MAGIC 1. Get client_id,tenant_id,client_secret from key vault.
# MAGIC 2. Set Spark Config with App/Client Id,Directory/Tenant ID and Secret. 
# MAGIC 3. Call file system utility mount from the storage.
# MAGIC 4. Explore other file system utilities related to mount(list all mounts,unmount)

# COMMAND ----------

client_id =dbutils.secrets.get(scope="f1-scope",key="f1-client-id")
tenant_id =dbutils.secrets.get(scope="f1-scope",key="f1-tenant-id")
client_secret=dbutils.secrets.get(scope="f1-scope",key="f1-client-secret")

# COMMAND ----------

configs= {"fs.azure.account.auth.type.formula1storageacc.dfs.core.windows.net": "OAuth"
,"fs.azure.account.oauth.provider.type.formula1storageacc.dfs.core.windows.net": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider"
,"fs.azure.account.oauth2.client.id.formula1storageacc.dfs.core.windows.net": client_id
,"fs.azure.account.oauth2.client.secret.formula1storageacc.dfs.core.windows.net": client_secret
,"fs.azure.account.oauth2.client.endpoint.formula1storageacc.dfs.core.windows.net": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}

# COMMAND ----------

configs = {
  "fs.azure.account.auth.type.formula1storageacc.dfs.core.windows.net": "OAuth",
  "fs.azure.account.oauth.provider.type.formula1storageacc.dfs.core.windows.net": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
  "fs.azure.account.oauth2.client.id.formula1storageacc.dfs.core.windows.net": client_id,
  "fs.azure.account.oauth2.client.secret.formula1storageacc.dfs.core.windows.net": dbutils.secrets.get(scope="f1-scope", key="f1-client-secret"),
  "fs.azure.account.oauth2.client.endpoint.formula1storageacc.dfs.core.windows.net": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
}


# COMMAND ----------

dbutils.secrets.list(scope="f1-scope")

# COMMAND ----------

dbutils.fs.mount(
    source="abfss://demo@formula1storageacc.dfs.core.windows.net/",
    mount_point="/mnt/formula1storage_demo",
    extra_configs=configs
)


# COMMAND ----------

dbutils.fs.unmount("/mnt/formula1storageacc/demo")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1storageacc.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("/mnt/formula1storageacc/demo/circuits.csv"))

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

