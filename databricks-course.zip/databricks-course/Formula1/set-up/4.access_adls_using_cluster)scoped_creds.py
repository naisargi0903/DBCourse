# Databricks notebook source
# MAGIC %md
# MAGIC ### Access Azure Data Lake using cluster scoped credentials
# MAGIC 1. set spark config fs.azure.account.key in the cluster
# MAGIC 2. List files from demo container
# MAGIC 3. Read data

# COMMAND ----------

dbutils.secrets.listScopes()


# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1storageacc.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1storageacc.dfs.core.windows.net"))

# COMMAND ----------

