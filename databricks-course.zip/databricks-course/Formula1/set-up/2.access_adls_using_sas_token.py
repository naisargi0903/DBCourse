# Databricks notebook source
# MAGIC %md
# MAGIC ### Access Azure Data Lake using SAS(Shared accesss signature) token
# MAGIC 1. set spark config for SAS token
# MAGIC 2. List files from demo container
# MAGIC 3. Read data

# COMMAND ----------

formula1sastoken=dbutils.secrets.get('f1-scope','sas-token-key')


# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1storageacc.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1storageacc.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
# spark.conf.set("fs.azure.sas.fixed.token.formula1storageacc.dfs.core.windows.net","sp=rl&st=2025-12-06T13:49:26Z&se=2025-12-06T22:04:26Z&spr=https&sv=2024-11-04&sr=c&sig=vd2m1WjTjlqtaVCX09XcytbBEXd0V68rngGCzSJs%2FZk%3D")

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1storageacc.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1storageacc.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.formula1storageacc.dfs.core.windows.net",formula1sastoken)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1storageacc.dfs.core.windows.net"))

# COMMAND ----------

