-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_raw;

-- COMMAND ----------

USE f1_raw;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Create external tables for csv files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create Circuits Table

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.circuits

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS f1_raw.circuits(
  circuitId INT,
  circuitRef STRING,
  name STRING,
  location STRING,
  country STRING,
  lat DOUBLE,
  lng DOUBLE,
  alt INT,
  url STRING)
  USING csv
  OPTIONS(path "abfss://raw@formula1storageacc.dfs.core.windows.net/circuits.csv",header true)

-- COMMAND ----------

SELECT * FROM f1_raw.circuits

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create Races table

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS f1_raw.races(
  raceId INT,
  year INT,
  round INT,
  circuitId INT,
  name STRING,
  date TIMESTAMP,
  time STRING,
  url STRING)
USING CSV
OPTIONS(path "abfss://raw@formula1storageacc.dfs.core.windows.net/races.csv",header true)

-- COMMAND ----------

SELECT * FROM f1_raw.races;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Create external tables for JSON files

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create table for constructors.json

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS f1_raw.constructors(
  constructorId INT,
  constructorRef STRING,
  name STRING,
  nationality STRING,
  url STRING)
USING JSON
OPTIONS(path "abfss://raw@formula1storageacc.dfs.core.windows.net/constructors.json")

-- COMMAND ----------

SELECT * FROM constructors;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create drivers table

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS drivers(
  driverId INT,
  driverRef STRING,
  number INT,
  code STRING,
  name STRUCT<forename: STRING, surname: STRING>,
  dob DATE,
  nationality STRING,
  url STRING
)
USING json
OPTIONS (path "abfss://raw@formula1storageacc.dfs.core.windows.net/drivers.json")

-- COMMAND ----------

SELECT *FROM f1_raw.drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create results table

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS results(
  resultId INT,
  raceId INT,
  driverId INT,
  constructorId INT,
  number INT,
  position INT,
  positionText STRING,
  positionOrder INT,
  points FLOAT,
  laps INT,
  time STRING,
  milliseconds INT,
  fastestLap INT,
  rank INT,
  fastestLapTime STRING,
  fastestLapSpeed FLOAT,
  statusID STRING
)
USING json
LOCATION "abfss://raw@formula1storageacc.dfs.core.windows.net/results.json"

-- COMMAND ----------

SELECT *FROM results

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create pitstops table

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS pitstops(
  driverId INT,
  duration STRING,
  lap INT,
  milliseconds INT,
  raceId INT,
  stop INT,
  time STRING
)
USING json
OPTIONS(path "abfss://raw@formula1storageacc.dfs.core.windows.net/pit_stops.json",multiLine true)

-- COMMAND ----------

SELECT *FROM pitstops

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Create table for folder

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create lap_times table

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS lap_times(
  raceId INT,
  driverId INT,
  lap INT,
  position INT,
  time STRING,
  milliseconds INT
)
USING csv
OPTIONS (path "abfss://raw@formula1storageacc.dfs.core.windows.net/lap_times", header true)

-- COMMAND ----------

SELECT  COUNT(1) FROM lap_times

-- COMMAND ----------

SELECT *FROM lap_times;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Create table for qualifying folder
-- MAGIC

-- COMMAND ----------

DROP TABLE IF EXISTS qualifying;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS qualifying(
  constructorId INT,
  driverId INT,
  number INT,
  position INT,
  q1 STRING,
  q2 STRING,
  q3 STRING,
  qualifyId INT,
  raceId INT
)
USING json
OPTIONS(path "abfss://raw@formula1storageacc.dfs.core.windows.net/qualifying",multiLine true)

-- COMMAND ----------

SELECT *FROM qualifying;

-- COMMAND ----------

DESC EXTENDED constructors;

-- COMMAND ----------

