# Databricks notebook source
# MAGIC %run ../includes/common_functions

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1: Ingest results.json

# COMMAND ----------

spark.read.json("abfss://raw@formula1storageacc.dfs.core.windows.net/2021-03-21/results.json").createOrReplaceTempView("results_cutover")

# COMMAND ----------

spark.read.json("abfss://raw@formula1storageacc.dfs.core.windows.net/2021-03-28/results.json").createOrReplaceTempView("results_w1")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT raceId,COUNT(1)
# MAGIC     FROM results_w1
# MAGIC   GROUP BY raceId
# MAGIC   ORDER BY raceId DESC

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-21")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

v_file_date

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,FloatType,DateType

# COMMAND ----------

results_schema= StructType(fields=[StructField("resultId",IntegerType(),False),
                                  StructField("raceId",IntegerType(),True),
                                  StructField("driverId",IntegerType(),True),
                                  StructField("constructorId",IntegerType(),True),
                                  StructField("number",IntegerType(),True),
                                  StructField("grid",IntegerType(),True),
                                  StructField("position",IntegerType(),True),
                                  StructField("positionText",StringType(),True),
                                  StructField("positionOrder",IntegerType(),True),
                                  StructField("points",FloatType(),True),
                                  StructField("laps",IntegerType(),True),
                                  StructField("time",StringType(),True),
                                  StructField("milliseconds",IntegerType(),True),
                                  StructField("fastestLap",IntegerType(),True),
                                  StructField("rank",IntegerType(),True),
                                  StructField("fastestLapTime",StringType(),True),
                                  StructField("fastestLapSpeed",FloatType(),True),
                                  StructField("statusId",StringType(),True)])

# COMMAND ----------

results_df=spark.read.option("header",True).schema(results_schema).json(f"abfss://raw@formula1storageacc.dfs.core.windows.net/{v_file_date}/results.json")

# COMMAND ----------

display(results_df)

# COMMAND ----------

results_df.printSchema() #printSchema for already loaded df,inferSchema as a option while loading df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Select/drop/rename the columns as req

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit
results_with_columns_df=results_df.withColumnRenamed('resultId','result_id')\
                                  .withColumnRenamed('raceId','race_id')\
                                  .withColumnRenamed('driverId','driver_id')\
                                  .withColumnRenamed('constructorId','constructor_id')\
                                  .withColumnRenamed('positionText','position_text')\
                                  .withColumnRenamed('positionOrder','position_order')\
                                  .withColumnRenamed('fastestLapTime','fastest_lap_time')\
                                  .withColumnRenamed('fastestLapSpeed','fastest_lap_speed')\
                                  .withColumn('ingestion_date',current_timestamp())\
                                  .withColumn('file_date',lit(v_file_date))

# COMMAND ----------

from pyspark.sql.functions import col
results_final_df=results_with_columns_df.drop(col('statusId'))
display(results_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3 : Write o/p to parquet file in datalake

# COMMAND ----------

#dbutils.fs.rm("abfss://processed@formula1storageacc.dfs.core.windows.net/results",recurse=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Method 1

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS f1_processed.results")


# COMMAND ----------

results_final_df.write.mode("append").partitionBy('race_id').format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

# %fs
# ls "abfss://processed@formula1storageacc.dfs.core.windows.net/results"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *FROM f1_processed.results

# COMMAND ----------

for race_id_row in results_final_df.select("race_id").distinct().collect():
    if (spark._jsparkSession.catalog().tableExists("f1_processed.results")):
        spark.sql(
        f"ALTER TABLE f1_processed.results DROP PARTITION (race_id={race_id_row.race_id})"
    )

# COMMAND ----------

results_final_df.write.mode("append").partitionBy('race_id').format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT race_id,COUNT(1)
# MAGIC   FROM f1_processed.results
# MAGIC   GROUP BY race_id
# MAGIC   ORDER BY race_id DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC ### Method 2

# COMMAND ----------

overwrite_partition(results_final_df, "f1_processed", "results", "race_id")

# COMMAND ----------

# spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")

# COMMAND ----------

# results_final_df.write.mode("overwrite").partitionBy('race_id').format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

