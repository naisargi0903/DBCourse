# Databricks notebook source
# MAGIC %md
# MAGIC ### Step 1: Ingest pistops.json

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType,FloatType,DateType

# COMMAND ----------

pit_stops_schema = StructType([StructField("raceId",IntegerType(),True),
                              StructField("driverId",IntegerType(),True),
                              StructField("stop",IntegerType(),True),
                              StructField("lap",IntegerType(),True),
                              StructField("time",StringType(),True),
                              StructField("duration",StringType(),True),
                              StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

pit_stops_df=spark.read.option("header",True).schema(pit_stops_schema).option("multiline",True).json("abfss://raw@formula1storageacc.dfs.core.windows.net/pit_stops.json") #spark by default does not consider multiline hence will give null in o/p

# COMMAND ----------

display(pit_stops_df)

# COMMAND ----------

pit_stops_df.printSchema() #printSchema for already loaded df,inferSchema as a option while loading df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Select/drop/rename the columns as req

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
pit_stops_final_df=pit_stops_df.withColumnRenamed('driverId','driver_id')\
.withColumnRenamed('raceId','race_id')\
.withColumn('ingestion_date',current_timestamp())
                                

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3 : Write o/p to parquet file in datalake

# COMMAND ----------

pit_stops_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.pit_stops")

# COMMAND ----------

# %fs
# ls "abfss://processed@formula1storageacc.dfs.core.windows.net/pit_stops"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *FROM f1_processed.pit_stops

# COMMAND ----------

