-- Databricks notebook source
DROP SCHEMA IF EXISTS f1_processed CASCADE

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_processed LOCATION "abfss://processed@formula1storageacc.dfs.core.windows.net/";

-- COMMAND ----------

DESC DATABASE f1_processed;

-- COMMAND ----------

