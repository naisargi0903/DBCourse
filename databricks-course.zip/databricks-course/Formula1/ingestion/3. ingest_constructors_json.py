# Databricks notebook source
# MAGIC %md
# MAGIC ### Step 1: Ingest constructors.json

# COMMAND ----------

# MAGIC %run "../includes/configuration"

# COMMAND ----------

constructor_schema= "constructorId INT, constructorRef STRING, name STRING, nationality STRING, url STRING" #DDL style schema definition

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-21")
v_file_date=dbutils.widgets.get("p_file_date")

# COMMAND ----------

constructor_df=spark.read.option("header",True).schema(constructor_schema).json(f"{raw_folder_path}/{v_file_date}/constructors.json")

# COMMAND ----------

display(constructor_df)

# COMMAND ----------

constructor_df.printSchema() #printSchema for already loaded df,inferSchema as a option while loading df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Select/drop the columns as req

# COMMAND ----------

constructor_dropped_df=constructor_df.drop(constructor_df.url)

# COMMAND ----------

constructor_dropped_df=constructor_df.drop('url')

# COMMAND ----------

constructor_dropped_df=constructor_df.drop(constructor_df['url'])

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

constructor_dropped_df=constructor_df.drop(col('url'))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Rename columns,add columns

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

constructor_final_df=constructor_dropped_df.withColumnRenamed('constructorId','constructor_id')\
                                            .withColumnRenamed('constructorRef','constructor_ref')\
                                            .withColumn('ingestion_date',current_timestamp())


# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3 : Write o/p to parquet file in datalake

# COMMAND ----------

constructor_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.constructors")

# COMMAND ----------

# DBTITLE 1,rcuotr
# %fs
# ls "abfss://processed@formula1storageacc.dfs.core.windows.net/constructors"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *FROM f1_processed.constructors

# COMMAND ----------

