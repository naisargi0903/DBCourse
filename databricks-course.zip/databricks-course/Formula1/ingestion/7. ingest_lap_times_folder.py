# Databricks notebook source
# MAGIC %md
# MAGIC ### Step 1: Ingest lap_times folder(with 5 csv files)

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType

# COMMAND ----------

lap_times_schema=StructType(fields=[StructField("raceId",IntegerType(),False),
                                   StructField("driverId",IntegerType(),True),
                                   StructField("lap",IntegerType(),True),
                                   StructField("position",IntegerType(),True),
                                   StructField("time",StringType(),True),
                                   StructField("milliseconds",IntegerType(),True)])

# COMMAND ----------

lap_times_df=spark.read.schema(lap_times_schema).csv("abfss://raw@formula1storageacc.dfs.core.windows.net/lap_times")

# COMMAND ----------

lap_times_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Select/rename/drop cols as req

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

lap_times_final_df=lap_times_df.withColumnRenamed("raceId","race_id") \
.withColumnRenamed("driverId","driver_id") \
.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3: Write output to processed container in parquet format

# COMMAND ----------

# lap_times_final_df.write.mode("overwrite").parquet("abfss://processed@formula1storageacc.dfs.core.windows.net/lap_times")

# COMMAND ----------

lap_times_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.lap_times")

# COMMAND ----------

# display(spark.read.parquet("abfss://processed@formula1storageacc.dfs.core.windows.net/lap_times"))

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.lap_times