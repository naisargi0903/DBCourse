# Databricks notebook source
# MAGIC %md
# MAGIC ### Step 1: Ingest qualifying folder

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType

# COMMAND ----------

qualifying_schema = StructType(fields=[StructField("qualifyId",IntegerType(),False),
                                       StructField("raceId",IntegerType(),True),
                                       StructField("driverId",IntegerType(),True),
                                       StructField("constructorId",IntegerType(),True),
                                       StructField("number",IntegerType(),True),
                                       StructField("position",IntegerType(),True),
                                       StructField("q1",StringType(),True),
                                       StructField("q2",StringType(),True),
                                       StructField("q3",StringType(),True)])

# COMMAND ----------

qualifying_df=spark.read.schema(qualifying_schema).option("multiline",True).json("abfss://raw@formula1storageacc.dfs.core.windows.net/qualifying")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2: Rename/select drop cols as needed

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
qualifying_final_df = qualifying_df.withColumnRenamed("qualifyId","qualify_id")\
.withColumnRenamed("raceId","race_id")\
.withColumnRenamed("driverId","driver_id")\
.withColumnRenamed("constructorId","constructor_id")\
.withColumn("ingestion_date",current_timestamp())


# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 3:Save in parquet format in datalake

# COMMAND ----------

# qualifying_final_df.write.mode("overwrite").parquet("abfss://processed@formula1storageacc.dfs.core.windows.net/qualifying")

# COMMAND ----------

qualifying_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.qualifying")

# COMMAND ----------

# %fs
# ls "abfss://processed@formula1storageacc.dfs.core.windows.net/qualifying"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *FROM f1_processed.qualifying

# COMMAND ----------

