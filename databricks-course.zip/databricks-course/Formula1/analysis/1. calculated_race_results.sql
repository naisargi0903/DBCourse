-- Databricks notebook source
USE f1_processed;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS f1_presentation.calculated_race_results
USING parquet
AS
SELECT races.race_year,constructors.name AS team_name,drivers.name AS driver_name,results.position,results.points,
  11-results.position AS calculated_points --position1:10pts,position 2:9pts ... for normalizing overall
  FROM results
  JOIN drivers on(results.driver_id = drivers.driver_id)
  JOIN constructors on(results.constructor_id = constructors.constructor_id)
  JOIN races on(results.race_id = races.race_id)
  WHERE results.position<=10
  ORDER BY race_year,calculated_points DESC

-- COMMAND ----------

SELECT *FROM f1_presentation.calculated_race_results;

-- COMMAND ----------

