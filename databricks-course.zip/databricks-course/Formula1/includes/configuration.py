# Databricks notebook source
raw_folder_path='abfss://raw@formula1storageacc.dfs.core.windows.net'
processed_folder_path='abfss://processed@formula1storageacc.dfs.core.windows.net'
presentation_folder_path='abfss://presentation@formula1storageacc.dfs.core.windows.net'
demo_folder_path ='abfss://demo@formula1storageacc.dfs.core.windows.net'

# COMMAND ----------

