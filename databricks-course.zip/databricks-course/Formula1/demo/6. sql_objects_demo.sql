-- Databricks notebook source
-- MAGIC %md
-- MAGIC #### Objectives:
-- MAGIC
-- MAGIC 1. Spark SQL documentation
-- MAGIC 2. Create database demo
-- MAGIC 3. Data tab in the UI(Catalog -> All -> Legacy -> Hive Metastore)
-- MAGIC 4. SHOW command
-- MAGIC 5. DESCRIBE command
-- MAGIC 6. Find the current database

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS demo;

-- COMMAND ----------

SHOW databases;

-- COMMAND ----------

DESC DATABASE demo;

-- COMMAND ----------

DESC DATABASE EXTENDED demo;

-- COMMAND ----------

SELECT current_database();

-- COMMAND ----------

SHOW TABLES in demo;

-- COMMAND ----------

USE demo;

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Managed Tables in SPARK
-- MAGIC 1. Create managed tables using python
-- MAGIC 2. Create managed table in SQL
-- MAGIC 3. Effect of dropping a managed table 
-- MAGIC 4. Describe table

-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").mode("overwrite").saveAsTable("demo.race_results_python")

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

DESC EXTENDED race_results_python

-- COMMAND ----------

SELECT * FROM race_results_python WHERE race_year=2020;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS race_results_sql 
AS
SELECT * FROM race_results_python WHERE race_year=2020;

-- COMMAND ----------

SELECT * FROM race_results_sql

-- COMMAND ----------

DESC EXTENDED race_results_sql;

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### External tables in SPARK
-- MAGIC 1. Create external table using Python
-- MAGIC 2. Create external table using SQL
-- MAGIC 3. Effect of dropping an external table
-- MAGIC 4. Describe table
-- MAGIC

-- COMMAND ----------

DROP TABLE demo.race_results_ext_py


-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").mode("overwrite").option("path",f"{demo_folder_path}/race_results_ext_py").saveAsTable("demo.race_results_ext_py")

-- COMMAND ----------

DESC EXTENDED race_results_ext_py;

-- COMMAND ----------

SHOW TABLES in demo;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC ext_table_path = f"{demo_folder_path}/race_results_ext_sql"
-- MAGIC spark.conf.set("ext_table_path", ext_table_path)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.conf.get("ext_table_path")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.sql(f"""
-- MAGIC CREATE TABLE demo.race_results_ext_sql(
-- MAGIC   race_year INT,
-- MAGIC   race_name STRING,
-- MAGIC   race_date TIMESTAMP,
-- MAGIC   circuit_location STRING,
-- MAGIC   driver_name STRING,
-- MAGIC   driver_number INT,
-- MAGIC   driver_nationality STRING,
-- MAGIC   grid INT,
-- MAGIC   fastestLap INT,
-- MAGIC   race_time STRING,
-- MAGIC   team STRING,
-- MAGIC   points FLOAT,
-- MAGIC   position INT, 
-- MAGIC   created_date TIMESTAMP
-- MAGIC )
-- MAGIC USING parquet
-- MAGIC LOCATION '{ext_table_path}';
-- MAGIC """)
-- MAGIC

-- COMMAND ----------

SHOW TABLES in demo;

-- COMMAND ----------

INSERT INTO demo.race_results_ext_sql
SELECT * FROM race_results_python WHERE race_year=2020;

-- COMMAND ----------

SELECT * FROM demo.race_results_ext_sql

-- COMMAND ----------

SELECT COUNT(1) FROM demo.race_results_ext_sql

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Views on tables
-- MAGIC 1. Create temp view
-- MAGIC 2. Create Globabl temp view
-- MAGIC 3. Create peramanent view
-- MAGIC

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_race_results
AS
SELECT * FROM demo.race_results_python WHERE race_year=2020;

-- COMMAND ----------

SELECT * FROM v_race_results;

-- COMMAND ----------

CREATE OR REPLACE GLOBAL TEMP VIEW gv_race_results
AS
SELECT * FROM demo.race_results_python WHERE race_year=2020;

-- COMMAND ----------

SELECT * FROM global_temp.gv_race_results

-- COMMAND ----------

CREATE OR REPLACE VIEW pv_race_results
AS
SELECT * FROM demo.race_results_python WHERE race_year=2000;

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

