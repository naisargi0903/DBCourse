# Databricks notebook source
# MAGIC %md
# MAGIC ### Databricks Magic Commands
# MAGIC - %python,%sql,%r,%scala:Switch to diff language for a specific cell
# MAGIC - %md:markdown(documenting,adding imgs,links)
# MAGIC - %fs:run file system commands
# MAGIC - %sh:run shell commands(driver node only)
# MAGIC - %pip:install python libraries
# MAGIC - %run:include/import another nb to current nb

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### %fs:run file system commands

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /databricks-datasets/ 

# COMMAND ----------

# MAGIC %md
# MAGIC ### %sh:run shell commands(driver node only)

# COMMAND ----------

# MAGIC %sh
# MAGIC ps #to know all running processes on driver node

# COMMAND ----------

# MAGIC %md
# MAGIC ### %pip:install python libraries

# COMMAND ----------

# MAGIC %pip list

# COMMAND ----------

# MAGIC %pip install faker # lib to genarte fake/dummy data

# COMMAND ----------

from faker import Faker
fake = Faker()
print(fake.name())
print(fake.address())
print(fake.email())

# COMMAND ----------

# MAGIC %md
# MAGIC ### %run:include/import another nb to current nb

# COMMAND ----------

# MAGIC %run "./2.1 Env Variables and Functions"
# MAGIC # This is it

# COMMAND ----------

env 

# COMMAND ----------

print_env_info()